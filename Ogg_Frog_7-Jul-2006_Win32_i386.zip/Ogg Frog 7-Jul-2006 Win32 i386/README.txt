Ogg Frog: Free Music Ripping, Encoding and Backup Program
http://www.oggfrog.com

Version: 7-Jul-2006

This is a very early test prototype of Ogg Frog.  It's barely started,
not nearly complete, and has lots of bugs.  Please check for production
quality releases at:

http://www.oggfrog.com/free-music-software

- Rippit the Ogg Frog
  rippit@oggfrog.com
  http://www.oggfrog.com
  
Ogg Frog: Free Music Ripping, Encoding and Backup Program
http://www.oggfrog.com/

Copyright (C) 2006 Michael David Crawford. 

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; version 2
of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.